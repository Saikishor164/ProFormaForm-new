
<?php include('dbconnect.php') ; ?>
<?php

$Dedutrustname = $_POST["Dedutrustname"];
$educationalname = $_POST["educationalname"];
$educationaladdress = $_POST["educationaladdress"];
$location = $_POST["location"];
$educationalcontact = $_POST["educationalcontact"];
$educationalmobile = $_POST["educationalmobile"];
$educationalemail = $_POST["educationalemail"];
$presidentname = $_POST["presidentname"];
$presidentcontact = $_POST["presidentcontact"];
$Presidentmobile = $_POST["Presidentmobile"];
$presidentemail = $_POST["presidentemail"];
$secretaryname = $_POST["secretaryname"];
$secretarycontact = $_POST["secretarycontact"];
$secretarymobile = $_POST["secretarymobile"];
$secretaryemail = $_POST["secretaryemail"];
$coordinatorname = $_POST["coordinatorname"];
$coordinatorcontact = $_POST["coordinatorcontact"];
$coordinatormobile = $_POST["coordinatormobile"];
$coordinatoremail = $_POST["coordinatoremail"];
$date = $_POST["date"];



    $sql = "INSERT INTO `pofoma1` (`Dedutrustname`, `educationalname`, `educationaladdress`, `location`, `educationalcontact`, `educationalmobile`, `educationalemail`, `presidentname`, `presidentcontact`, `Presidentmobile`, `presidentemail`, `secretaryname`, `secretarycontact`, `secretarymobile`, `secretaryemail`, `coordinatorname`, `coordinatorcontact`, `coordinatormobile`, `coordinatoremail`, `date`)
    VALUES ('$Dedutrustname', '$educationalname', '$educationaladdress', '$location', 
    '$educationalcontact', '$educationalmobile', '$educationalemail', '$presidentname', 
    '$presidentcontact', '$Presidentmobile', '$presidentemail', '$secretaryname', 
    '$secretarycontact', '$secretarymobile', '$secretaryemail', '$coordinatorname', 
    '$coordinatorcontact', '$coordinatormobile', '$coordinatoremail', '$date')
    ON DUPLICATE KEY UPDATE
    Dedutrustname = VALUES(Dedutrustname),
    educationalname = VALUES(educationalname),
    educationaladdress = VALUES(educationaladdress),
    location = VALUES(location),
    educationalcontact = VALUES(educationalcontact),
    educationalmobile = VALUES(educationalmobile),
    educationalemail = VALUES(educationalemail),
    presidentname = VALUES(presidentname),
    presidentcontact = VALUES(presidentcontact),
    Presidentmobile = VALUES(Presidentmobile),
    presidentemail = VALUES(presidentemail),
    secretaryname = VALUES(secretaryname),
    secretarycontact = VALUES(secretarycontact),
    secretarymobile = VALUES(secretarymobile),
    secretaryemail = VALUES(secretaryemail),
    coordinatorname = VALUES(coordinatorname),
    coordinatorcontact = VALUES(coordinatorcontact),
    coordinatormobile = VALUES(coordinatormobile),
    coordinatoremail = VALUES(coordinatoremail),
    date = VALUES(date)";
$rs = mysqli_query($con, $sql);

if($rs)
{
    require ("fpdf185/fpdf.php");

    $pdf = new FPDF();
    $pdf->AddPage();
 
    $pdf->SetFont ("Arial", "", 12); 
 $pdf->Cell (0, 10, "Profoma submitted for the establishment of P.A Inamdar Computer Lab",1,1, 'C');
 $pdf->Cell (0, 10, "Proforma No.1231",1,1, 'C');
 $pdf->Cell (60, 10, "Name of the Educational Trust: ",1,0, 'C');
 $pdf->Cell (0, 10, "$Dedutrustname",1,1, 'L');
 $pdf->Cell (20, 10, "Others:",1,0, 'C');
 $pdf->Cell (0, 10, "$educationalname",1,1, 'L');
 $pdf->Cell (0, 10, "Proforma No.1231",1,1, 'C');


 $pdf->output();

 $pdf->AddPage();

    header("Location: form2.html");

    exit;
   }

?>
