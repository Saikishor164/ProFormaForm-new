<?php 

$con= new mysqli('localhost','root','','proforma')or die("Could not connect to mysql".mysqli_error($con));